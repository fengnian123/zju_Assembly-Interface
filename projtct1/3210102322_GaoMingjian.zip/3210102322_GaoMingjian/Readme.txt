Contains the test.c program, the test.exe executable, and the test.s disassembly code
1. Compile and run test.c directly with the c language compiler, and the specific buffer size can be changed at will
2. Use gcc -s or objdump to disassemble test.exe